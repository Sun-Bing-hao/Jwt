# JWT登录鉴权练习Demo

## 这个demo帮你理解什么
- 密码为什么要用BCrypt加密存储，而不是明文或者简单MD5
- JWT的生成、解析、校验全流程
- Spring Security的过滤器链是怎么工作的，自定义过滤器怎么插进去
- 为什么说JWT是"无状态"鉴权

## 怎么跑起来
1. 用IDEA打开这个项目（File -> Open -> 选中jwt-auth-demo文件夹），等Maven把依赖下载完
2. 确认JDK用的是8（File -> Project Structure -> Project SDK）
3. 直接运行 `AuthDemoApplication.java` 的 main方法
4. 看到控制台打印Tomcat启动在8080端口，并且输出了建表的SQL语句，就说明启动成功了

## 怎么测试（用Postman或者IDEA自带的.http文件工具都行）

### 第一步：注册
```
POST http://localhost:8080/auth/register
Content-Type: application/json

{
  "username": "testuser",
  "password": "123456"
}
```
返回 `{"code":200,"message":"success","data":"注册成功"}` 就说明成功了。

你可以打开浏览器访问 `http://localhost:8080/h2-console`，JDBC URL填 `jdbc:h2:mem:authdemo`，
用户名`sa`密码留空，点连接，去USER表里看一眼，你会发现password字段存的是一长串类似
`$2a$10$xxxxx...`的密文，不是你输入的"123456"，这就是BCrypt加密后的样子。

### 第二步：登录
```
POST http://localhost:8080/auth/login
Content-Type: application/json

{
  "username": "testuser",
  "password": "123456"
}
```
返回的data字段就是一长串JWT Token，形如 `eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0ZXN0dXNlciIsImlhdCI6...`，
注意观察它是用两个点分成三段的，对应header.payload.signature。

你可以把中间那段payload拿去 jwt.io 这个网站解码看看（只是解码，不是解密，任何人都能看payload内容），
能看到里面有你的用户名和过期时间，但signature部分不知道密钥是解不出来的。

### 第三步：不带Token访问受保护接口，应该失败
```
GET http://localhost:8080/test/profile
```
应该会返回401或403，因为没带Token，走到SecurityConfig里配置的anyRequest().authenticated()这条规则。

### 第四步：带着Token访问，应该成功
```
GET http://localhost:8080/test/profile
Authorization: Bearer 把上一步拿到的token粘贴到这里
```
注意Bearer后面有个空格。应该返回类似
`{"code":200,"message":"success","data":"你好, testuser，你已通过鉴权访问到了受保护的接口"}`

## 建议你动手做的几个实验（加深理解）
1. 把Token随便改动一个字符再去请求，观察是不是校验失败了（体会"防篡改"）
2. 把 application.yml 里的 jwt.expiration 改成 10000（10秒），登录后等10秒再访问，
   观察是不是提示Token失效了（体会"过期机制"）
3. 想一下：如果要实现"用户登出"，让一个Token立刻失效，这套最简单的实现能做到吗？
   （提示：想不到答案很正常，这是JWT的一个经典痛点，面试常问，你可以先带着问题，
   后面学到Redis之后我们可以聊聊怎么结合Redis做"Token黑名单"来解决这个问题）
4. 对比一下，如果你不用Security的StatefulSession而用Session-Cookie的传统方式做登录，
   和现在这种JWT方式，各自的优缺点是什么？（这是面试高频问题）

## 代码该怎么看
建议按这个顺序读：
AuthController（入口） -> JwtUtil（生成/解析Token的核心） ->
JwtAuthFilter（每个请求怎么被拦截校验的） -> SecurityConfig（整体鉴权规则怎么配的）
