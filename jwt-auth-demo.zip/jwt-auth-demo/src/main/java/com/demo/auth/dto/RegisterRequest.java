package com.demo.auth.dto;

import lombok.Data;

@Data
public class RegisterRequest {
    private String username;
    private String password; // 这里收到的是前端传来的明文密码，到Service层才会加密
}
