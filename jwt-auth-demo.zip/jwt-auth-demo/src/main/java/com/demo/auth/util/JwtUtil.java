package com.demo.auth.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;

/**
 * JWT核心工具类：生成Token、解析Token
 *
 * JWT的组成是三段，用.分隔： header.payload.signature
 * - header：声明类型(JWT)和加密算法(比如HS256)，Base64编码
 * - payload：存放实际数据(比如用户名、过期时间)，Base64编码，注意这里不是加密，是编码，
 *            任何人拿到Token都能解出payload内容看到，所以不要往里塞敏感信息（比如密码）
 * - signature：服务端用密钥对前两段内容做签名，别人没有密钥就无法伪造一个合法的Token，
 *              这是JWT防篡改的核心——如果有人改了payload里的内容，签名对不上，服务端校验就会失败
 */
@Component
public class JwtUtil {

    @Value("${jwt.secret}")
    private String secret;

    @Value("${jwt.expiration}")
    private long expiration;

    private Key getSigningKey() {
        return Keys.hmacShaKeyFor(secret.getBytes());
    }

    /**
     * 生成Token，把用户名放进payload
     */
    public String generateToken(String username) {
        Date now = new Date();
        Date expireDate = new Date(now.getTime() + expiration);

        return Jwts.builder()
                .setSubject(username)          // 把用户名存入payload的subject字段
                .setIssuedAt(now)               // 签发时间
                .setExpiration(expireDate)      // 过期时间，JWT会自动校验这个
                .signWith(getSigningKey(), SignatureAlgorithm.HS256) // 用密钥+算法生成签名
                .compact();
    }

    /**
     * 从Token中解析出用户名
     * 如果Token被篡改过，或者已经过期，这里会抛异常
     */
    public String getUsernameFromToken(String token) {
        Claims claims = Jwts.parserBuilder()
                .setSigningKey(getSigningKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
        return claims.getSubject();
    }

    /**
     * 校验Token是否合法（签名正确且未过期）
     */
    public boolean validateToken(String token) {
        try {
            Jwts.parserBuilder().setSigningKey(getSigningKey()).build().parseClaimsJws(token);
            return true;
        } catch (Exception e) {
            // 签名不对、格式不对、已过期，都会落到这里，统一判定为无效
            return false;
        }
    }
}
