package com.demo.auth.config;

import com.demo.auth.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collections;

/**
 * 每个请求进来都会先经过这个过滤器（继承OncePerRequestFilter保证每个请求只执行一次）
 *
 * 核心流程：
 * 1. 从请求头Authorization里取出Token（约定格式："Bearer xxx.xxx.xxx"）
 * 2. 校验Token合法性
 * 3. 如果合法，把用户信息放进Spring Security的上下文(SecurityContextHolder)，
 *    后续的Controller/Service里就可以知道"当前是谁在请求"
 * 4. 如果不合法或者没带Token，就不设置登录态，请求会在后面被Security拦下（如果该接口需要登录的话）
 */
@Component
public class JwtAuthFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtil jwtUtil;

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                     @NonNull HttpServletResponse response,
                                     @NonNull FilterChain filterChain) throws ServletException, IOException {

        String authHeader = request.getHeader("Authorization");

        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7); // 去掉"Bearer "前缀，拿到真正的token字符串

            if (jwtUtil.validateToken(token)) {
                String username = jwtUtil.getUsernameFromToken(token);

                // 构造一个Authentication对象放进Spring Security上下文
                // 这里简化处理，没有做角色/权限区分，第二个参数通常放密码，登录后不需要可以传null
                UsernamePasswordAuthenticationToken authentication =
                        new UsernamePasswordAuthenticationToken(username, null, Collections.emptyList());

                SecurityContextHolder.getContext().setAuthentication(authentication);
            }
        }

        // 不管前面校验结果如何，都要放行到下一个过滤器/最终的Controller
        // 真正的拦截动作交给Spring Security的授权规则去判断（见SecurityConfig）
        filterChain.doFilter(request, response);
    }
}
