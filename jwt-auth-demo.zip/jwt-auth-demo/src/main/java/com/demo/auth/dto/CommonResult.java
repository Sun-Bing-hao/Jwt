package com.demo.auth.dto;

import lombok.Data;

/**
 * 统一返回结果封装，mall项目里你会看到类似的CommonResult类
 * 让所有接口的返回格式保持一致，前端处理起来更方便
 */
@Data
public class CommonResult<T> {
    private int code;
    private String message;
    private T data;

    public static <T> CommonResult<T> success(T data) {
        CommonResult<T> result = new CommonResult<>();
        result.setCode(200);
        result.setMessage("success");
        result.setData(data);
        return result;
    }

    public static <T> CommonResult<T> failed(String message) {
        CommonResult<T> result = new CommonResult<>();
        result.setCode(500);
        result.setMessage(message);
        return result;
    }
}
