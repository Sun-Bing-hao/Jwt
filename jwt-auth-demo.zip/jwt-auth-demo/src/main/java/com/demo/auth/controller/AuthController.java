package com.demo.auth.controller;

import com.demo.auth.dto.CommonResult;
import com.demo.auth.dto.LoginRequest;
import com.demo.auth.dto.RegisterRequest;
import com.demo.auth.entity.User;
import com.demo.auth.repository.UserRepository;
import com.demo.auth.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;

    /**
     * 注册接口
     * 核心点：拿到前端传来的明文密码后，一定要用BCrypt加密后再存库，绝不能存明文
     */
    @PostMapping("/register")
    public CommonResult<String> register(@RequestBody RegisterRequest request) {
        if (userRepository.findByUsername(request.getUsername()) != null) {
            return CommonResult.failed("用户名已存在");
        }

        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(passwordEncoder.encode(request.getPassword())); // 加密存储
        userRepository.save(user);

        return CommonResult.success("注册成功");
    }

    /**
     * 登录接口
     * 核心点：用BCryptPasswordEncoder.matches()比对明文密码和库里的密文，
     * 不能自己再对输入的密码加密一遍去跟库里的密文做字符串相等比较（因为BCrypt每次加密结果都不同）
     */
    @PostMapping("/login")
    public CommonResult<String> login(@RequestBody LoginRequest request) {
        User user = userRepository.findByUsername(request.getUsername());

        if (user == null) {
            return CommonResult.failed("用户不存在");
        }

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            return CommonResult.failed("密码错误");
        }

        // 登录校验通过，生成Token返回给前端
        String token = jwtUtil.generateToken(user.getUsername());
        return CommonResult.success(token);
    }
}
