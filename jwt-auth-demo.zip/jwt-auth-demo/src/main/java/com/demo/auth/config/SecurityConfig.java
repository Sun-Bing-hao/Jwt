package com.demo.auth.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * Spring Security 核心配置
 *
 * 几个关键点先建立概念：
 * 1. SessionCreationPolicy.STATELESS：告诉Security不要用session保存登录状态，
 *    因为我们用JWT做无状态鉴权，每次请求靠Token自证身份，不依赖服务端存session
 * 2. csrf().disable()：CSRF防护是基于session的攻击防护机制，我们不用session了，所以关掉
 * 3. 把自己写的JwtAuthFilter，加在Security默认的用户名密码过滤器之前，
 *    这样每个请求会先被我们的过滤器处理，解析出Token对应的登录信息
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private JwtAuthFilter jwtAuthFilter;

    @Bean
    public PasswordEncoder passwordEncoder() {
        // BCrypt：一种单向哈希加密算法，同样的密码每次加密结果都不同（因为内置随机盐），
        // 没法反向解密，只能用matches方法拿明文和密文比对，这是存储密码的标准做法
        return new BCryptPasswordEncoder();
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .csrf().disable()
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .authorizeRequests()
                    .antMatchers("/auth/**").permitAll()      // 注册、登录接口不需要登录就能访问
                    .antMatchers("/h2-console/**").permitAll() // 放开H2控制台，方便你调试看数据
                    .anyRequest().authenticated()              // 其余所有接口都必须带合法Token
                .and()
                .headers().frameOptions().disable(); // H2控制台需要用到iframe，这里放开一下

        // 把我们自己的JWT过滤器加到Security默认过滤器链的前面
        http.addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);
    }
}
