package com.demo.auth.repository;

import com.demo.auth.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * 继承JpaRepository后，不用写实现类，Spring Data JPA会自动根据方法名生成SQL
 * 比如 findByUsername 会被解析成 select * from user where username = ?
 */
public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
}
