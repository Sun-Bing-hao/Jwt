package com.demo.auth.controller;

import com.demo.auth.dto.CommonResult;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 这个接口没有在SecurityConfig里被permitAll放行，
 * 所以请求必须带合法的Token才能访问，用来验证整条鉴权链路是否生效
 */
@RestController
public class TestController {

    @GetMapping("/test/profile")
    public CommonResult<String> profile() {
        // 能走到这里，说明JwtAuthFilter已经校验通过并把用户名放进了上下文
        String username = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return CommonResult.success("你好, " + username + "，你已通过鉴权访问到了受保护的接口");
    }
}
